package org.tuc;

public interface Element {

    /**
     * Returns the key of this element
     * 
     * @return the key of the element
     */
    public int getKey();
}
