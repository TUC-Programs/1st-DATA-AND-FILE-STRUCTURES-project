package org.tuc;

public class Globals {

    public static final int numCounter = 10;
    public static final int AAList_MaxSize = 500000;
	public static final int N[] = { 30, 50, 100, 200, 500, 1000, 5000, 10000, 100000};
	public static final String separator = "==========================================================";
	public static final String separator1 = "----------------------------------------------------------------\n";
	public static final int NumberOfList = 6;
	public static final String fileName = "Data";
	
	public static final int MAX_INT_NUMBER = 100000000;
	public static final int MIN_INT_NUMBER = -100000000;
	public static final int SUCCESS_SEARCHES = 1000;
	public static final int FAILURE_SEARCHES = 1000;
	
}
