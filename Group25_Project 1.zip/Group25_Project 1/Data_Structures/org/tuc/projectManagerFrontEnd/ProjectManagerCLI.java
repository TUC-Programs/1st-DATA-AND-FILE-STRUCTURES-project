package org.tuc.projectManagerFrontEnd;


import org.tuc.searchtest.Tester;

public class ProjectManagerCLI {

    public static void main(String[] args) {
        
        System.out.println("Begin the test for different type of lists");
        Tester.ListTester();
        System.out.println("Completed all...");
    }
}
