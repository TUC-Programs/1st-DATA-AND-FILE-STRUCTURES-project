package org.tuc.searchtest;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.tuc.Element;
import org.tuc.Globals;
import org.tuc.Lists;
import org.tuc.MyElement;
import org.tuc.counter.MultiCounter;
import org.tuc.list.AAList;
import org.tuc.list.AList;
import org.tuc.list.DList;
import org.tuc.list.SAAList;
import org.tuc.list.SAList;
import org.tuc.list.SDList;


public class Tester {
    private static long InsertListDur[][] = new long[Globals.N.length][6];
    private static long DeleteListDur[][] = new long[Globals.N.length][6];
    private static long SearchListDur[][] = new long[Globals.N.length][6];

    private static long[][][] Actions  = new long[Globals.N.length][6][3];;
    private static String[] lists= {"DList", "SDList", "AAList", "SAAList", "AList", "SAList"};
    //private static long[][] DeleteActions = new long[6][3];
    //private static long[][] SearchActions = new long[6][3];
   
    public static Random r= new Random(); //create random numbers

    //insert elements random to lists
    public static Long insert(Lists list, int size){
        long beginTime=System.nanoTime();
        for(int i=0; i<Globals.N.length; i++){
            int key = r.nextInt(size*2)+1;
            Element e= new MyElement(key);
            list.insert(e);
        }
        long finishTime=System.nanoTime();
        long duration = finishTime - beginTime;
        //System.out.println("   Insert time: "+duration+"ns");
        return duration;

    }

    //delete elements
    public static Long delete(Lists list, int size){
        long beginTime=System.nanoTime();
        for(int i=0; i<size; i++){
            int key = r.nextInt(size*2)+1;
            list.delete(key);
        }
        long finishTime=System.nanoTime();
        long duration = finishTime - beginTime;
        //System.out.println("   Delete time: "+duration+"ns");
        return duration;
    }

    //serach for an element
    public static Long search(Lists list, int size){
        long beginTime=System.nanoTime();
        for(int i=0; i<size; i++){
            int key = r.nextInt(size*2)+1;
            list.search(key);
        }
        long finishTime=System.nanoTime();
        long duration = finishTime - beginTime;
        //System.out.println("   Search time: "+duration+"ns");
        return duration;
    }

    // Find the number of repeat for each node number
    public static int RepeatTestCalc(int size){
        int K;
        if(size<201){
            K=10;
        }else if(size<1001){
            K=50;
        }else{
            K=100;
        }
        return K;
    }

    //Test the insert,delete,search for all the 6 types of lists and gets the necessary info
    public static void ListTester(){
        List headings = new ArrayList();
        headings.add("List Type");
        headings.add("Number of Nodes");
        headings.add("Mean Insert Time(ns)");
        headings.add("Mean Delete Time(ns)");
        headings.add("Mean Search time(ns)");
        headings.add("Mean Insert Actions");
        headings.add("Mean Delete Actions");
        headings.add("Mean Search actions");
        TestDataCollector testDataCollector = new TestDataCollector(headings);
    
        
        for(int i=0; i<Globals.N.length; i++){
            int NodeNum = Globals.N[i];
            System.out.println("Starting test for: "+NodeNum+" Nodes");
            int repeatTest = RepeatTestCalc(NodeNum);
            
            for(int j = 0; j < 6; j++){
                InsertListDur[i][j] = 0;
                DeleteListDur[i][j] = 0;
                SearchListDur[i][j] = 0;
                for(int k = 0; k < 3; k++){
                    Actions[i][j][k] = 0;
                }
            }
            for(int j = 0; j < repeatTest; j++){
                //System.out.println("--Starting test for: "+ NodeNum+ " Test: "+ j);
                //System.out.println(" -Prossesing Dlist ...");
                Lists dlist= new DList();
                InsertListDur[i][0] += insert(dlist, NodeNum);
                DeleteListDur[i][0] += delete(dlist, NodeNum);
                SearchListDur[i][0] += search(dlist, NodeNum);
                Actions[i][0][0] += MultiCounter.getCount(1);
                Actions[i][0][1] += MultiCounter.getCount(2);
                Actions[i][0][2] += MultiCounter.getCount(3);
                for(int k = 1; k < 4; k++){
                    MultiCounter.resetCounter(k);
                }

                //System.out.println(" -Prossesing SDlist ...");
                Lists sdlist= new SDList();
                InsertListDur[i][1] += insert(sdlist, NodeNum);
                DeleteListDur[i][1] += delete(sdlist, NodeNum);
                SearchListDur[i][1] += search(sdlist, NodeNum);
                Actions[i][1][0] += MultiCounter.getCount(1);
                Actions[i][1][1] += MultiCounter.getCount(2);
                Actions[i][1][2] += MultiCounter.getCount(3);
                for(int k = 1; k < 4; k++){
                    MultiCounter.resetCounter(k);
                }

                //System.out.println(" -Prossesing AAlist ...");
                Lists aaList= new AAList();
                InsertListDur[i][2] += insert(aaList, NodeNum);
                DeleteListDur[i][2] += delete(aaList, NodeNum);
                SearchListDur[i][2] += search(aaList, NodeNum);
                Actions[i][2][0] += MultiCounter.getCount(1);
                Actions[i][2][1] += MultiCounter.getCount(2);
                Actions[i][2][2] += MultiCounter.getCount(3);
                for(int k = 1; k < 4; k++){
                    MultiCounter.resetCounter(k);
                }

                //System.out.println(" -Prossesing SAAlist ...");
                Lists saaList= new SAAList();
                InsertListDur[i][3] += insert(saaList, NodeNum);
                DeleteListDur[i][3] += delete(saaList, NodeNum);
                SearchListDur[i][3] += search(saaList, NodeNum);
                Actions[i][3][0] += MultiCounter.getCount(1);
                Actions[i][3][1] += MultiCounter.getCount(2);
                Actions[i][3][2] += MultiCounter.getCount(3);
                for(int k = 1; k < 4; k++){
                    MultiCounter.resetCounter(k);
                }

                //System.out.println(" -Prossesing Alist ...");
                Lists aList= new AList(NodeNum);
                InsertListDur[i][4] += insert(aList, NodeNum);
                DeleteListDur[i][4] += delete(aList, NodeNum);
                SearchListDur[i][4] += search(aList, NodeNum);
                Actions[i][4][0] += MultiCounter.getCount(1);
                Actions[i][4][1] += MultiCounter.getCount(2);
                Actions[i][4][2] += MultiCounter.getCount(3);
                for(int k = 1; k < 4; k++){
                    MultiCounter.resetCounter(k);
                }

                //System.out.println(" -Prossesing SAlist ...");
                Lists salist =new SAList(NodeNum);
                InsertListDur[i][5] += insert(salist, NodeNum);
                DeleteListDur[i][5] += delete(salist, NodeNum);
                SearchListDur[i][5] += search(salist, NodeNum);
                Actions[i][5][0] += MultiCounter.getCount(1);
                Actions[i][5][1] += MultiCounter.getCount(2);
                Actions[i][5][2] += MultiCounter.getCount(3);
                for(int k = 1; k < 4; k++){
                    MultiCounter.resetCounter(k);
                }
            }

            InsertListDur = computeAverageTime(InsertListDur,repeatTest,i);
            DeleteListDur = computeAverageTime(DeleteListDur,repeatTest,i);
            SearchListDur = computeAverageTime(SearchListDur,repeatTest,i);
            Actions = computeAverageActions(Actions, repeatTest, i);

            //Preparing elements for printing
            for(int p = 0; p < Globals.NumberOfList; p++){
                List results = new ArrayList();
                results.add(lists[p]);
                results.add(Globals.N[i]);
                results.add((float)InsertListDur[i][p]);
                results.add((float)DeleteListDur[i][p]);
                results.add((float)SearchListDur[i][p]);
                results.add((float)Actions[i][p][0]);
                results.add((float)Actions[i][p][1]);
                results.add((float)Actions[i][p][2]);
                testDataCollector.addRow(results);
            }
            
        }
        testDataCollector.toScreen();
        testDataCollector.toFile(Globals.fileName+".csv");
    }

    // Calculate average run time for each option for every list
    public static long[][] computeAverageTime(long List[][], int repeatTest, int i){
        for(int j = 0; j < 6; j++){
            List[i][j] /= (long)repeatTest;
        }
        return List;
    }
    public static long[][][] computeAverageActions(long List[][][], int repeatTest, int i){
        for(int k = 0; k < 6; k++){
            for(int j = 0; j < 3; j++){
                List[i][k][j] /= (long)repeatTest;
            }
        }
        return List;
    }
}
