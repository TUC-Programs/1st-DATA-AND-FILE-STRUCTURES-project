package org.tuc.searchtest;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class TestDataCollector {
     /**
	 * Holds the headings of the table
	 */
	private List<String> headings;
	
	/**
	 * Holds the measurements as a list for each row
	 */
	private List<List> rows;
	
	/**
	 * Constructor
	 * @param headings Headings
	 */
	public TestDataCollector(List headings) {
		this.headings = headings;
		rows = new ArrayList();
	}
    
    /**
	 * Adds a row with measurements
	 * @param row row with measurements
	 */
	public void addRow(List row) {
		rows.add(row);
	}
	
	public void toScreen() {
		// print headings
		this.print(System.out, " | ");
		System.out.println("Data collected printed to screen");
	}

    public void toFile(String fileName) {
		try {
			PrintStream printStream = new PrintStream(fileName);
			this.print(printStream, ",");
			printStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		System.out.println("Data collected saved to "+fileName);
	}

    
    private void print(PrintStream printStream, String separator) {
        // Print headings
        for (int i = 0; i < headings.size(); i++) {
            printStream.print(headings.get(i));
            if (i < headings.size() - 1) {
                printStream.print(separator);
            }
        }
        printStream.println();

        // Print rows
        for (List row : rows) {
            for (int j = 0; j < row.size(); j++) {
                int columnWidth = headings.get(j).length();
                Object value = row.get(j);
                if (value instanceof Integer) {
                    printStream.printf("%" + columnWidth + "d", value);
                } else if (value instanceof Float) {
                    printStream.printf("%" + columnWidth + ".3f", value);
                } else {
                    printStream.printf("%" + columnWidth + "s", value);
                }
                if (j < row.size() - 1) {
                    printStream.print(separator);
                }
            }
            printStream.println();
        }
    }

}
