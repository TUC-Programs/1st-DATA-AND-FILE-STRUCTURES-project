package org.tuc.list;

import org.tuc.Element;
import org.tuc.counter.MultiCounter;

public class SDList extends DList{


    public SDList(){
        super();  //call the superclass constructor
    }

    
    @Override
    public boolean insert(Element element) {
        try {
            Node nNod=new Node(element);
            
            if(MultiCounter.increaseCounter(1) && head==null){ //if empty list
                head=nNod;  //head and tail point new node
                tail=nNod;
            }
            else{
                Node present = head;
                Node previous= null;
                while (present!=null){
                    previous=present;
                    present=present.next;
                }
                
                if(MultiCounter.increaseCounter(1) && previous==null){ //if insert is the first
                    nNod.next=nNod;
                    head=nNod;
                }
                else{ //insert in other positions
                    previous.next=nNod;
                    nNod.next=present;
                }
                if(MultiCounter.increaseCounter(1) && nNod.next==null){//insert in the end 
                    tail=nNod;
                }
            }
    
            return true;
        } catch (Exception ex) {
            System.err.println("Error during insertion..." + ex.getMessage());
            return false;
        }
    }


    @Override
    public boolean delete(int key) {
        
        try{
            
            Node present = head;
            Node previous= null;
            
            while(present!= null){
                
                if(MultiCounter.increaseCounter(2) && present.element.getKey()==key){//Ckeck the key witch be deleted exist
                    if(MultiCounter.increaseCounter(2) && previous==null){ //if it is the first node
                        head= present.next;//update head
                    } 
                    else{
                        previous.next= present.next;//remove the node from the list
                    }               
                }
                
                if(MultiCounter.increaseCounter(2) && present==tail){//if is last node
                    tail=previous;//update tail
                }
                previous= present; //move previous to present
                present =present.next; //move to next node
            }

            return false; //key not found


        }catch (Exception ex){
            return false;
        }
    }


    @Override
    public Element search(int key) {
        
        try{
            Node present =head;

            while(present!=null){
                
                if(MultiCounter.increaseCounter(3) && present.element.getKey() == key){//check if the key is correct
                    return present.element; //return element
                }
                
                present= present.next;//move next node
            }
            return null;

        }catch(Exception ex){
            return null;
        }
        
    }

   


}
