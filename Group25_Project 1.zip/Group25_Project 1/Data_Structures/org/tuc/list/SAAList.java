package org.tuc.list;

import org.tuc.Element;
import org.tuc.counter.MultiCounter;

public class SAAList extends AAList {

    public SAAList(){
        super();
    }

    @Override
    public boolean insert(Element element){
        try{
            int index = nextfree1;                    
            elementArray[index] = new MyElement(element, element.getKey());                   // Adding the current element to the next free position that we have
            nextfree1 = pointerArray[nextfree1];                                              // Getting the pointer of the recently added pointer for the next position
            
            int temp = -1;
            length = length + 1;
            if(MultiCounter.increaseCounter(1) && length == 1){
                head1 = index;
                tail1 = index;
            }

            if(MultiCounter.increaseCounter(1) && length > 1 && length < 4){
                for(int i = 0; i < length; i++){                    // Finding the tail and head of the current elements in the list
                    if(MultiCounter.increaseCounter(1) && elementArray[head1].element.getKey() > elementArray[i].element.getKey() && head1 != i){
                        pointerArray[i] = head1;
                        head1 = i;
                    }else if(MultiCounter.increaseCounter(1) && elementArray[tail1].element.getKey() < elementArray[i].element.getKey() && tail1 != i){
                        pointerArray[tail1] = i;
                        tail1 = i;
                    }else if(MultiCounter.increaseCounter(1) && elementArray[tail1].element.getKey() > elementArray[i].element.getKey() && elementArray[head1].element.getKey() < elementArray[i].element.getKey()){
                        pointerArray[i] = tail1;
                        pointerArray[head1] = i;
                    }
                    else if(MultiCounter.increaseCounter(1) && elementArray[tail1].element.getKey() == elementArray[i].element.getKey()){
                        pointerArray[i] = pointerArray[tail1];
                    }else if(MultiCounter.increaseCounter(1) && elementArray[head1].element.getKey() == elementArray[i].element.getKey()){
                        pointerArray[i] = pointerArray[head1];
                    }
                }
                pointerArray[tail1] = -1;
            }
    
            int pointer = head1;                    //Setting the pointer index to the head to start sorting
            if(MultiCounter.increaseCounter(1) && length > 3){
                for(int i = 0; i < length; i++){
                    int nextPoint = pointerArray[pointer];
                    if(MultiCounter.increaseCounter(1) && elementArray[nextPoint].element.getKey() <= elementArray[index].element.getKey() && nextPoint == tail1){ //Checks if the new element is bigger than the tail
                        pointerArray[nextPoint] = index;
                        pointerArray[index] = -1;
                        tail1 = index;
                    }
                    //Checks if the new elements is between two other elements
                    else if(MultiCounter.increaseCounter(1) && elementArray[pointer].element.getKey() <= elementArray[index].element.getKey() && elementArray[nextPoint].element.getKey() >= elementArray[index].element.getKey() && pointer != head1 && nextPoint != head1 && pointer != tail1 && nextPoint != tail1){
                        pointerArray[index] = nextPoint;
                        pointerArray[pointer] = index;
                    }
                    else if(MultiCounter.increaseCounter(1) && elementArray[pointer].element.getKey() >= elementArray[index].element.getKey() && pointer == head1){    //Checks if the new element is smaller than the head
                        pointerArray[index] = pointer;
                        head1 = index;
                    }else{
                        pointer = pointerArray[pointer];    //Points to the next element based of the currents element pointer
                    }
                }
            }
            return true;

        }catch(Exception ex){
            return false;
        }
    }

    @Override
    public boolean delete(int key){
        try {
            for(int i = 0; i < MAX_SIZE; i++){
                if(MultiCounter.increaseCounter(2) && elementArray[i].element.getKey() == key){
                    elementArray[i] = null;                         //Deletes the requested element
                    nextfree1 = i;                                  //Sets the next free position to be the one where the element got deleted

                    if(MultiCounter.increaseCounter(2) && head1 == i){                 //When the head of the list is deleted
                        head1 = pointerArray[i];
                    }else if(tail1 == i && MultiCounter.increaseCounter(2)){           //When the tail of the list is deleted
                        for(int j = 0; j < MAX_SIZE; j++){                                          //Searching for the pointer to the tail
                            if(pointerArray[j] == i && MultiCounter.increaseCounter(2)){
                                tail1 = j;                          //Sets the index num as the new tail
                                pointerArray[j] = -1;               //Sets the pointer of the new tail to -1
                            }
                        }
                    }else{
                        for(int j = 0; j < MAX_SIZE; j++){          //Searching for the previous element
                            if(MultiCounter.increaseCounter(2) && pointerArray[j] == i){
                                pointerArray[j] = pointerArray[i];  //Sets the previous element pointer to point at the next element
                            }
                        }
                    }
                    break;
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
        
    }

    @Override
    public Element search(int key){
        int pointer = head1;
        try {
            for(int i = 0; i < length; i++){
                if(MultiCounter.increaseCounter(3) && elementArray[pointer].element.getKey() == key){
                    return elementArray[pointer].element;
                }else if(MultiCounter.increaseCounter(3) && pointerArray[pointer] == -1){
                    return null;
                }else{
                    pointer = pointerArray[pointer];
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }
}
