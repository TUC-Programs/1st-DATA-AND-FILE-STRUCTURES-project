package org.tuc.list;


import org.tuc.Element;
import org.tuc.Lists;
import org.tuc.counter.MultiCounter;

public class DList implements Lists{

    public Node head;
    public Node tail;
  
    
    public class Node {
        Element element;
        Node next;
        //constructor for Node class
        Node(Element element) {
            this.element = element;
            this.next = null;
        }
    }



    @Override
    public boolean insert(Element element){
        try{
            Node newNode= new Node(element);
            if(MultiCounter.increaseCounter(1) && head==null ){      //if list is empty
                head=newNode;     //head, tail point to show a new Node
                tail= newNode;
            }
            else{    //if not empty list
                tail.next=newNode; //new node after the tail
                tail=newNode;      //update the tail when put new node
            }
            return true;

        }catch(Exception ex){
            return false;
        }
    }


    @Override
    public boolean delete(int key) {
        
        try{
            Node present = head;
            Node previous= null;
            
            while(present!= null){
                if(MultiCounter.increaseCounter(2) && present.element.getKey()==key){ //Ckeck the key witch be deleted exist
                    if(MultiCounter.increaseCounter(2) && previous==null){ //if it is the first node
                        head= present.next; //update head
                    } 
                    else{
                        previous.next= present.next; //remove the node from the list
                    }               
                }
                if(MultiCounter.increaseCounter(2) && present==tail){ //last node be deleted
                    tail=previous;//update tail
                }
                previous= present;  //move previous to present
                present =present.next; //move next node
            }

            return false; //key not found


        }catch (Exception ex){
            return false;
        }
    }


    @Override
    public Element search(int key) {
        try{
            Node present =head;
            while(head!=null){
                if(MultiCounter.increaseCounter(3) && present.element.getKey() == key){ //check if the key is the key that be searched
                    return present.element; //return element
                }
                present =present.next; //move next node
            }
            return null;

        }catch(Exception ex){
            return null;
        }
        
    }




}

