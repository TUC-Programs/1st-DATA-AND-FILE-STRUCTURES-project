package org.tuc.list;

import org.tuc.Lists;
import org.tuc.counter.MultiCounter;
import org.tuc.Element;


public class AList implements Lists{

    protected Element[] myArray;
    protected int size=0;
   
    //constructor of AList
    public AList(int capasity){
        myArray= new Element[capasity];
    }

    @Override
    public boolean insert(Element element){
        try{
           if(MultiCounter.increaseCounter(1) && size < myArray.length){//check we have enough space 
                myArray[size++]=element; //insert the element and increase the size by 1
           }
            return true;

        }catch(Exception ex){
            return false;
        }
    }

    @Override
    public boolean delete(int key){
        try{
            for(int i=0; i<size; i++){
                if(MultiCounter.increaseCounter(2) && myArray[i].getKey()==key){ //if key exist to delete
                    System.arraycopy(myArray, i+1, myArray, i, size-i-1); //shift elements left
                    size--; //decrement size by 1 when we delete an element
                    return true;
                }
            }
            return false; //key not found

        }catch(ArrayIndexOutOfBoundsException ex){
            System.err.println("Array index out of bounds."+ex.getMessage());
        }
        return false;
    }

    @Override
    public Element search(int key){
        try{
            for(int i=0; i<size; i++){
                if(MultiCounter.increaseCounter(3) && myArray[i].getKey()==key){ //check if the key is correct
                    return myArray[i];  //return the element that find
                }
            }

            return null;

        }catch(Exception ex){
            return null;
        }
    }

    

}
