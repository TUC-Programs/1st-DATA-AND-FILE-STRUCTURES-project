package org.tuc.list;

import org.tuc.Element;
import org.tuc.counter.MultiCounter;


public class SAList extends AList{

    //constructor of SAList
    public SAList(int capasity){
        super(capasity); //call the superclass constructor
        

    }

    @Override
    public boolean insert(Element element){
        //check if we not have enough capasity to put elements
        if(MultiCounter.increaseCounter(1) && size == myArray.length){
            return false;       //array is full
        }

        int index = binarySearch(element.getKey()); //find the insert position using binary search
        if(MultiCounter.increaseCounter(1) && index<0){ //if element do not exist
            index =-(index+1);//compute the correct position
        }

        //move elements to the right
        System.arraycopy(myArray, index, myArray, index+1, size-index);
        myArray[index]=element; //insert the element in the correct position
        size++; //increase the size by 1 when we put an element
        return true;

    }


    @Override
    public boolean delete(int key){
        int index =binarySearch(key); //use binary search to find the element
        if(MultiCounter.increaseCounter(2) && index>=0){ //element exist
            System.arraycopy(myArray, index+1, myArray, index, size-index-1); //shift to the right
            size--;//decrement the size ny 1 when we delete an element
            return true;
        }
        
        return false;
    }

    @Override
    public Element search(int key){
        int index=binarySearch(key); //use binary search
        if(MultiCounter.increaseCounter(3) && index>=0){ 
            return myArray[index];//return the element if we find
        }
        else{
            return null; //null if we not find
        }
    }

    
    public int binarySearch(int key){
        int left = 0;
        int right = size - 1;
    
        while (left <= right) {
            int mid = left + (right - left) / 2;
            Element midE= myArray[mid];
            int comp=Integer.compare(midE.getKey(), key);
            if (comp<0) {
                left=mid+1;
            }
            else if (comp>0){
                right=mid-1;
            }
            else{
                return mid;
            }
        }
        return -(left + 1);
    }



    
}
