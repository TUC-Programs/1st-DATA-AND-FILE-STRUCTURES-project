package org.tuc;


public class Node{

    Element element;
    Node next;
    int key;

    public Node(Element el){
        this.element=el;
        this.key=key;
    }


    
    //Getters and Setters 
    public int getKey() {
        return key;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }

}
